package com.cse.ds;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestStudent {

	static Student obj = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//TODO
	}

	@Test
	public void testHashCode() {
		//TODO
	}

	@Test
	public void testEquals() {
		//TODO
	}
}
