package com.cse.ds;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.Matchers;

public class TestController {
	
	static Controller obj = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//TODO
	}
		
	//TODO
	public void testGetNullPIDStudent() throws Exception {
		//TODO
	}

	@Test
	public void testGetStudentFound() {
		//TODO
	}
	
	@Test
	public void testGetStudentNotFound() {
		//TODO
	}	
}
