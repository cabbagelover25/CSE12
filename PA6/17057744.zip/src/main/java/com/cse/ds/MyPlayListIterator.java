/** Author: Samuel Kapusta
 * Email: skapusta@ucsd.edu
 * Date: April 17, 2019
 *
 * Contains MyPlayListIterator Class that extends the MyListIterator class.
 **/

package com.cse.ds;

import java.util.NoSuchElementException;

/** MyPlayListIterator enables the user to traverse through the songs in their pplaylist */
public class MyPlayListIterator<E> implements MyListIterator<E> {

    private int nsongs;
    private int position;
    Song dummy;
    Song left;
    Song right;
    int forward = 0;

    /** Constuctor for MyPlayListIterator that uses parameters from 
 	* MyPlaylist of nsums and dummy
 	* to update variables. 	 
 	* @param: Int of current index
 	* @param: Dummy song
 	*/
    public MyPlayListIterator(int i, Song dummy){
        this.nsongs = i;
        this.position = 0;
        this.dummy = dummy;
        this.left = dummy;
        this.right = left.getNext();
    }

    /** Checks of their is a next song at the current spot of the playlist.
 	* @return: Boolean of whether a next song exists 
 	*/
    @Override
    public boolean hasNext() {
        if(dummy.getNext() == null && right != null){
            return false;
        }
        else{
            return true;
        }
    }

    /** Updates the iterator one spot in the playlist
 	* @return: Return previous element of current song in Iterator. 
 	*/ 
    @Override
    public E next() throws NoSuchElementException {

        if (right == null){
            throw new NoSuchElementException();
        }

        position += 1;
        left = right;
        right = right.getNext();
        forward = 1;
        return (E) left.getElement();
    }

    /** Checks if their is a previous Song in current Iterator spot.
	* Returns boolean based on if previous value exists.
 	*/ 
    @Override
    public boolean hasPrevious() {
        if (left == null) {
            return false;
        } else {
            return true;
        }
    }

    /** Moves one Song back in Iterator.
 	* @return: Returns previous data of Song  
 	*/ 
    @Override
    public E previous() throws NoSuchElementException{
        if(left == null){
            throw new NoSuchElementException();
        }
        position -= 1;
        right = left;
        left = left.getNext();
        forward = -1;
        return (E)right.getElement();
    }

    /** Returns current position of Iterator.
 	* @return: Position of Iterator. 
 	*/ 
    @Override
    public int nextIndex() {
        return position;
                // maybe +1 not sure;
    }

    /** Returns previous index of Iterator.
 	* @return: Previous index of iterator.	 
 	*/ 
    @Override
    public int previousIndex() {
        return position -= 1; 
    }

    /** Set E value of Song that the Iterator was last on.
 	* @param: Data to change in Song 
 	*/ 
    @Override
    public void set(E o) throws NullPointerException, IllegalStateException {
        if (o == null){
            throw new NullPointerException();
        }
        if (forward == 0){
            throw new IllegalStateException();
        }
        if(forward == 1){
            left.setElement(o);
        }
        if (forward == -1){
            right.setElement(o);
        }
    }



}
