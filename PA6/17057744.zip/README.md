# CSE12
Repository for CSE 12 projects

In this PA we use a Playlist and Songs classes to replicate a LinkedList and Node relationship. LinkedList traverses through a set of items not by having a set previous structure but by setting the previous and last items on the nodes to their corrective counterparts. Thus, even though the individual nodes only have access to the last and next items, the playlist is able to traverse through all of them in an effecient manner through the MyPlayListIterator class. 

Sam Kapusta, skapusta@ucsd.edu, A15666223
